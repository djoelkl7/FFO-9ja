function bt(u){return u&&u.__esModule&&Object.prototype.hasOwnProperty.call(u,"default")?u.default:u}var ie={exports:{}},Y={exports:{}};Y.exports;var Pe;function Tt(){return Pe||(Pe=1,(function(u,n){/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(){function m(e,t){Object.defineProperty(k.prototype,e,{get:function(){console.warn("%s(...) is deprecated in plain JavaScript React classes. %s",t[0],t[1])}})}function h(e){return e===null||typeof e!="object"?null:(e=Ee&&e[Ee]||e["@@iterator"],typeof e=="function"?e:null)}function g(e,t){e=(e=e.constructor)&&(e.displayName||e.name)||"ReactClass";var r=e+"."+t;be[r]||(console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",t,e),be[r]=!0)}function k(e,t,r){this.props=e,this.context=t,this.refs=se,this.updater=r||Te}function b(){}function w(e,t,r){this.props=e,this.context=t,this.refs=se,this.updater=r||Te}function _(){}function j(e){return""+e}function T(e){try{j(e);var t=!1}catch{t=!0}if(t){t=console;var r=t.error,o=typeof Symbol=="function"&&Symbol.toStringTag&&e[Symbol.toStringTag]||e.constructor.name||"Object";return r.call(t,"The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",o),j(e)}}function R(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===_t?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case re:return"Fragment";case me:return"Profiler";case ye:return"StrictMode";case ve:return"Suspense";case kt:return"SuspenseList";case ge:return"Activity";case we:return"ViewTransition"}if(typeof e=="object")switch(typeof e.tag=="number"&&console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."),e.$$typeof){case pe:return"Portal";case ke:return e.displayName||"Context";case oe:return(e._context.displayName||"Context")+".Consumer";case _e:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case ae:return t=e.displayName||null,t!==null?t:R(e.type)||"Memo";case U:t=e._payload,e=e._init;try{return R(e(t))}catch{}}return null}function $(e){if(e===re)return"<>";if(typeof e=="object"&&e!==null&&e.$$typeof===U)return"<...>";try{var t=R(e);return t?"<"+t+">":"<...>"}catch{return"<...>"}}function C(){var e=c.A;return e===null?null:e.getOwner()}function y(){return Error("react-stack-top-frame")}function E(e){if(G.call(e,"key")){var t=Object.getOwnPropertyDescriptor(e,"key").get;if(t&&t.isReactWarning)return!1}return e.key!==void 0}function M(e,t){function r(){Se||(Se=!0,console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",t))}r.isReactWarning=!0,Object.defineProperty(e,"key",{get:r,configurable:!0})}function N(){var e=R(this.type);return Oe[e]||(Oe[e]=!0,console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release.")),e=this.props.ref,e!==void 0?e:null}function S(e,t,r,o,a,d){var s=r.ref;return e={$$typeof:ne,type:e,key:t,props:r,_owner:o},(s!==void 0?s:null)!==null?Object.defineProperty(e,"ref",{enumerable:!1,get:N}):Object.defineProperty(e,"ref",{enumerable:!1,value:null}),e._store={},Object.defineProperty(e._store,"validated",{configurable:!1,enumerable:!1,writable:!0,value:0}),Object.defineProperty(e,"_debugInfo",{configurable:!1,enumerable:!1,writable:!0,value:null}),Object.defineProperty(e,"_debugStack",{configurable:!1,enumerable:!1,writable:!0,value:a}),Object.defineProperty(e,"_debugTask",{configurable:!1,enumerable:!1,writable:!0,value:d}),Object.freeze&&(Object.freeze(e.props),Object.freeze(e)),e}function X(e,t){return t=S(e.type,t,e.props,e._owner,e._debugStack,e._debugTask),e._store&&(t._store.validated=e._store.validated),t}function I(e){A(e)?e._store&&(e._store.validated=1):typeof e=="object"&&e!==null&&e.$$typeof===U&&(e._payload.status==="fulfilled"?A(e._payload.value)&&e._payload.value._store&&(e._payload.value._store.validated=1):e._store&&(e._store.validated=1))}function A(e){return typeof e=="object"&&e!==null&&e.$$typeof===ne}function Z(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(r){return t[r]})}function q(e,t){return typeof e=="object"&&e!==null&&e.key!=null?(T(e.key),Z(""+e.key)):t.toString(36)}function J(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(_,_):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function P(e,t,r,o,a){var d=typeof e;(d==="undefined"||d==="boolean")&&(e=null);var s=!1;if(e===null)s=!0;else switch(d){case"bigint":case"string":case"number":s=!0;break;case"object":switch(e.$$typeof){case ne:case pe:s=!0;break;case U:return s=e._init,P(s(e._payload),t,r,o,a)}}if(s){s=e,a=a(s);var i=o===""?"."+q(s,0):o;return Ce(a)?(r="",i!=null&&(r=i.replace(je,"$&/")+"/"),P(a,t,r,"",function(O){return O})):a!=null&&(A(a)&&(a.key!=null&&(s&&s.key===a.key||T(a.key)),r=X(a,r+(a.key==null||s&&s.key===a.key?"":(""+a.key).replace(je,"$&/")+"/")+i),o!==""&&s!=null&&A(s)&&s.key==null&&s._store&&!s._store.validated&&(r._store.validated=2),a=r),t.push(a)),1}if(s=0,i=o===""?".":o+":",Ce(e))for(var f=0;f<e.length;f++)o=e[f],d=i+q(o,f),s+=P(o,t,r,d,a);else if(f=h(e),typeof f=="function")for(f===e.entries&&(ze||console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."),ze=!0),e=f.call(e),f=0;!(o=e.next()).done;)o=o.value,d=i+q(o,f++),s+=P(o,t,r,d,a);else if(d==="object"){if(typeof e.then=="function")return P(J(e),t,r,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return s}function x(e,t,r){if(e==null)return e;var o=[],a=0;return P(e,o,"","",function(d){return t.call(r,d,a++)}),o}function mt(e){if(e._status===-1){var t=null,r=null,o=e._ioInfo;o!=null&&(o.start=o.end=performance.now(),o.value=new Promise(function(s,i){t=s,r=i})),o=e._result;var a=o();if(a.then(function(s){if(e._status===0||e._status===-1){e._status=1,e._result=s;var i=e._ioInfo;if(i!=null){i.end=performance.now();var f=s==null?void 0:s.default;t(f),i.value.status="fulfilled",i.value.value=f}a.status===void 0&&(a.status="fulfilled",a.value=s)}},function(s){if(e._status===0||e._status===-1){e._status=2,e._result=s;var i=e._ioInfo;i!=null&&(i.end=performance.now(),i.value.then(_,_),r(s),i.value.status="rejected",i.value.reason=s),a.status===void 0&&(a.status="rejected",a.reason=s)}}),o=e._ioInfo,o!=null){var d=a.displayName;typeof d=="string"&&(o.name=d)}e._status===-1&&(e._status=0,e._result=a)}if(e._status===1)return o=e._result,o===void 0&&console.error(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`,o),"default"in o||console.error(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`,o),o.default;throw e._result}function p(){var e=c.H;return e===null&&console.error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`),e}function fe(){c.asyncTransitions--}function de(e){var t=c.T,r={};r.types=t!==null?t.types:null,r._updatedFibers=new Set,c.T=r;try{var o=e(),a=c.S;a!==null&&a(r,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&(c.asyncTransitions++,o.then(fe,fe),o.then(_,$e))}catch(d){$e(d)}finally{t===null&&r._updatedFibers&&(e=r._updatedFibers.size,r._updatedFibers.clear(),10<e&&console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")),t!==null&&r.types!==null&&(t.types!==null&&t.types!==r.types&&console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."),t.types=r.types),c.T=t}}function he(e){var t=c.T;if(t!==null){var r=t.types;r===null?t.types=[e]:r.indexOf(e)===-1&&r.push(e)}else c.asyncTransitions===0&&console.error("addTransitionType can only be called inside a `startTransition()` callback. It must be associated with a specific Transition."),de(he.bind(null,e))}function B(e){if(Q===null)try{var t=("require"+Math.random()).slice(0,7);Q=(u&&u[t]).call(u,"timers").setImmediate}catch{Q=function(o){De===!1&&(De=!0,typeof MessageChannel>"u"&&console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));var a=new MessageChannel;a.port1.onmessage=o,a.port2.postMessage(void 0)}}return Q(e)}function W(e){return 1<e.length&&typeof AggregateError=="function"?new AggregateError(e):e[0]}function F(e,t){t!==V-1&&console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "),V=t}function ee(e,t,r){var o=c.actQueue;if(o!==null)if(o.length!==0)try{te(o),B(function(){return ee(e,t,r)});return}catch(a){c.thrownErrors.push(a)}else c.actQueue=null;0<c.thrownErrors.length?(o=W(c.thrownErrors),c.thrownErrors.length=0,r(o)):t(e)}function te(e){if(!ue){ue=!0;var t=0;try{for(;t<e.length;t++){var r=e[t];do{c.didUsePromise=!1;var o=r(!1);if(o!==null){if(c.didUsePromise){e[t]=r,e.splice(0,t);return}r=o}else break}while(!0)}e.length=0}catch(a){e.splice(0,t+1),c.thrownErrors.push(a)}finally{ue=!1}}}typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart=="function"&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());var ne=Symbol.for("react.transitional.element"),pe=Symbol.for("react.portal"),re=Symbol.for("react.fragment"),ye=Symbol.for("react.strict_mode"),me=Symbol.for("react.profiler"),oe=Symbol.for("react.consumer"),ke=Symbol.for("react.context"),_e=Symbol.for("react.forward_ref"),ve=Symbol.for("react.suspense"),kt=Symbol.for("react.suspense_list"),ae=Symbol.for("react.memo"),U=Symbol.for("react.lazy"),ge=Symbol.for("react.activity"),we=Symbol.for("react.view_transition"),Ee=Symbol.iterator,be={},Te={isMounted:function(){return!1},enqueueForceUpdate:function(e){g(e,"forceUpdate")},enqueueReplaceState:function(e){g(e,"replaceState")},enqueueSetState:function(e){g(e,"setState")}},Re=Object.assign,se={};Object.freeze(se),k.prototype.isReactComponent={},k.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},k.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};var v={isMounted:["isMounted","Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],replaceState:["replaceState","Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]};for(H in v)v.hasOwnProperty(H)&&m(H,v[H]);b.prototype=k.prototype,v=w.prototype=new b,v.constructor=w,Re(v,k.prototype),v.isPureReactComponent=!0;var Ce=Array.isArray,_t=Symbol.for("react.client.reference"),c={H:null,A:null,T:null,S:null,actQueue:null,asyncTransitions:0,isBatchingLegacy:!1,didScheduleLegacyUpdate:!1,didUsePromise:!1,thrownErrors:[],getCurrentStack:null,recentlyCreatedOwnerStacks:0},G=Object.prototype.hasOwnProperty,Me=console.createTask?console.createTask:function(){return null};v={react_stack_bottom_frame:function(e){return e()}};var Se,Ae,Oe={},vt=v.react_stack_bottom_frame.bind(v,y)(),gt=Me($(y)),ze=!1,je=/\/+/g,$e=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},De=!1,Q=null,V=0,K=!1,ue=!1,Ne=typeof queueMicrotask=="function"?function(e){queueMicrotask(function(){return queueMicrotask(e)})}:B;v=Object.freeze({__proto__:null,c:function(e){return p().useMemoCache(e)}});var H={map:x,forEach:function(e,t,r){x(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return x(e,function(){t++}),t},toArray:function(e){return x(e,function(t){return t})||[]},only:function(e){if(!A(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};n.Activity=ge,n.Children=H,n.Component=k,n.Fragment=re,n.Profiler=me,n.PureComponent=w,n.StrictMode=ye,n.Suspense=ve,n.ViewTransition=we,n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=c,n.__COMPILER_RUNTIME=v,n.act=function(e){var t=c.actQueue,r=V;V++;var o=c.actQueue=t!==null?t:[],a=!1;try{var d=e()}catch(f){c.thrownErrors.push(f)}if(0<c.thrownErrors.length)throw F(t,r),e=W(c.thrownErrors),c.thrownErrors.length=0,e;if(d!==null&&typeof d=="object"&&typeof d.then=="function"){var s=d;return Ne(function(){a||K||(K=!0,console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"))}),{then:function(f,O){a=!0,s.then(function(L){if(F(t,r),r===0){try{te(o),B(function(){return ee(L,f,O)})}catch(Et){c.thrownErrors.push(Et)}if(0<c.thrownErrors.length){var wt=W(c.thrownErrors);c.thrownErrors.length=0,O(wt)}}else f(L)},function(L){F(t,r),0<c.thrownErrors.length&&(L=W(c.thrownErrors),c.thrownErrors.length=0),O(L)})}}}var i=d;if(F(t,r),r===0&&(te(o),o.length!==0&&Ne(function(){a||K||(K=!0,console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"))}),c.actQueue=null),0<c.thrownErrors.length)throw e=W(c.thrownErrors),c.thrownErrors.length=0,e;return{then:function(f,O){a=!0,r===0?(c.actQueue=o,B(function(){return ee(i,f,O)})):f(i)}}},n.addTransitionType=he,n.cache=function(e){return function(){return e.apply(null,arguments)}},n.cacheSignal=function(){return null},n.captureOwnerStack=function(){var e=c.getCurrentStack;return e===null?null:e()},n.cloneElement=function(e,t,r){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=Re({},e.props),a=e.key,d=e._owner;if(t!=null){var s;e:{if(G.call(t,"ref")&&(s=Object.getOwnPropertyDescriptor(t,"ref").get)&&s.isReactWarning){s=!1;break e}s=t.ref!==void 0}s&&(d=C()),E(t)&&(T(t.key),a=""+t.key);for(i in t)!G.call(t,i)||i==="key"||i==="__self"||i==="__source"||i==="ref"&&t.ref===void 0||(o[i]=t[i])}var i=arguments.length-2;if(i===1)o.children=r;else if(1<i){s=Array(i);for(var f=0;f<i;f++)s[f]=arguments[f+2];o.children=s}for(o=S(e.type,a,o,d,e._debugStack,e._debugTask),a=2;a<arguments.length;a++)I(arguments[a]);return o},n.createContext=function(e){return e={$$typeof:ke,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:oe,_context:e},e._currentRenderer=null,e._currentRenderer2=null,e},n.createElement=function(e,t,r){for(var o=2;o<arguments.length;o++)I(arguments[o]);var a;o={};var d=null;if(t!=null)for(a in Ae||!("__self"in t)||"key"in t||(Ae=!0,console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")),E(t)&&(T(t.key),d=""+t.key),t)G.call(t,a)&&a!=="key"&&a!=="__self"&&a!=="__source"&&(o[a]=t[a]);var s=arguments.length-2;if(s===1)o.children=r;else if(1<s){for(var i=Array(s),f=0;f<s;f++)i[f]=arguments[f+2];Object.freeze&&Object.freeze(i),o.children=i}if(e&&e.defaultProps)for(a in s=e.defaultProps,s)o[a]===void 0&&(o[a]=s[a]);return d&&M(o,typeof e=="function"?e.displayName||e.name||"Unknown":e),(a=1e4>c.recentlyCreatedOwnerStacks++)?(i=Error.stackTraceLimit,Error.stackTraceLimit=10,s=Error("react-stack-top-frame"),Error.stackTraceLimit=i):s=vt,S(e,d,o,C(),s,a?Me($(e)):gt)},n.createRef=function(){var e={current:null};return Object.seal(e),e},n.forwardRef=function(e){e!=null&&e.$$typeof===ae?console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."):typeof e!="function"?console.error("forwardRef requires a render function but was given %s.",e===null?"null":typeof e):e.length!==0&&e.length!==2&&console.error("forwardRef render functions accept exactly two parameters: props and ref. %s",e.length===1?"Did you forget to use the ref parameter?":"Any additional parameter will be undefined."),e!=null&&e.defaultProps!=null&&console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");var t={$$typeof:_e,render:e},r;return Object.defineProperty(t,"displayName",{enumerable:!1,configurable:!0,get:function(){return r},set:function(o){r=o,e.name||e.displayName||(Object.defineProperty(e,"name",{value:o}),e.displayName=o)}}),t},n.isValidElement=A,n.lazy=function(e){e={_status:-1,_result:e};var t={$$typeof:U,_payload:e,_init:mt},r={name:"lazy",start:-1,end:-1,value:null,owner:null,debugStack:Error("react-stack-top-frame"),debugTask:console.createTask?console.createTask("lazy()"):null};return e._ioInfo=r,t._debugInfo=[{awaited:r}],t},n.memo=function(e,t){e==null&&console.error("memo: The first argument must be a component. Instead received: %s",e===null?"null":typeof e),t={$$typeof:ae,type:e,compare:t===void 0?null:t};var r;return Object.defineProperty(t,"displayName",{enumerable:!1,configurable:!0,get:function(){return r},set:function(o){r=o,e.name||e.displayName||(Object.defineProperty(e,"name",{value:o}),e.displayName=o)}}),t},n.startTransition=de,n.unstable_useCacheRefresh=function(){return p().useCacheRefresh()},n.use=function(e){return p().use(e)},n.useActionState=function(e,t,r){return p().useActionState(e,t,r)},n.useCallback=function(e,t){return p().useCallback(e,t)},n.useContext=function(e){var t=p();return e.$$typeof===oe&&console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?"),t.useContext(e)},n.useDebugValue=function(e,t){return p().useDebugValue(e,t)},n.useDeferredValue=function(e,t){return p().useDeferredValue(e,t)},n.useEffect=function(e,t){return e==null&&console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?"),p().useEffect(e,t)},n.useEffectEvent=function(e){return p().useEffectEvent(e)},n.useId=function(){return p().useId()},n.useImperativeHandle=function(e,t,r){return p().useImperativeHandle(e,t,r)},n.useInsertionEffect=function(e,t){return e==null&&console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?"),p().useInsertionEffect(e,t)},n.useLayoutEffect=function(e,t){return e==null&&console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?"),p().useLayoutEffect(e,t)},n.useMemo=function(e,t){return p().useMemo(e,t)},n.useOptimistic=function(e,t){return p().useOptimistic(e,t)},n.useReducer=function(e,t,r){return p().useReducer(e,t,r)},n.useRef=function(e){return p().useRef(e)},n.useState=function(e){return p().useState(e)},n.useSyncExternalStore=function(e,t,r){return p().useSyncExternalStore(e,t,r)},n.useTransition=function(){return p().useTransition()},n.version="19.3.1",typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop=="function"&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error())})()})(Y,Y.exports)),Y.exports}var Le;function Rt(){return Le||(Le=1,ie.exports=Tt()),ie.exports}var z=Rt();const Pt=bt(z);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ct=u=>u==null?void 0:u.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function Mt(u,n,m=[]){if(n==null)throw new Error("[lucide]: iconNode is required when icon name is used");return{name:Ct(u),size:24,node:n,...m.length>0?{aliases:m}:{}}}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const St=u=>{let n="",m=!1;for(const h of u){if(h==="-"||h==="_"||h<=" "){m=n.length>0;continue}n.length===0?n+=h.toLowerCase():n+=m?h.toUpperCase():h,m=!1}return n};/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const At=u=>{const n=St(u);return n.charAt(0).toUpperCase()+n.slice(1)};/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=(...u)=>u.filter((n,m,h)=>!!n&&n.trim()!==""&&h.indexOf(n)===m).join(" ").trim();/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function ce(u){return u!=null}function Ot(u,n={}){var $,C;const m=n.attributeNames??{},h=y=>m[y]??y,g=u.size??u.width??D.width,k=u.size??u.height??D.height,b=(($=u.aliases)==null?void 0:$.filter(y=>typeof y=="string"&&y.trim()!=="").map(y=>`lucide-${y}`))??[],w=[...u.name?[`lucide-${u.name}`]:[],...b],_=((C=n.className)==null?void 0:C.split(" ").filter(Boolean))??[],j=n.includeDefaultClasses===!1?le(..._):le("lucide",...w,..._),T=n.absoluteStrokeWidth?Number(n.strokeWidth??D["stroke-width"])*Number(u.size??u.width??D.width)/Number(n.size??n.width??D.width):n.strokeWidth??D["stroke-width"];return["svg",{...Object.entries(D).reduce((y,[E,M])=>(y[h(E)]=M,y),{}),..."color"in n&&n.color&&{[h("stroke")]:n.color},..."size"in n&&ce(n.size)&&{[h("width")]:n.size,[h("height")]:n.size},..."width"in n&&ce(n.width)&&{[h("width")]:n.width},..."height"in n&&ce(n.height)&&{[h("height")]:n.height},[h("stroke-width")]:T,...j&&{[h("class")]:j},[h("viewBox")]:`0 0 ${g} ${k}`,...n.hasA11yProp===!1?{[h("aria-hidden")]:"true"}:{},..."attributes"in n&&n.attributes},u.node.map(y=>{const[E,M,N]=y,S=n.nonScalingStroke?{[h("vector-effect")]:"non-scaling-stroke",...M}:M;return N?[E,S,N]:[E,S]})]}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function zt(u,n={}){return Ot(u,{...n,attributeNames:{...n.attributeNames,class:"className","stroke-width":"strokeWidth","stroke-linecap":"strokeLinecap","stroke-linejoin":"strokeLinejoin","vector-effect":"vectorEffect"}})}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jt=u=>{for(const n in u)if(n.startsWith("aria-")||n==="role"||n==="title")return!0;return!1},$t=z.createContext({}),Dt=()=>z.useContext($t),Nt=z.forwardRef(({color:u,size:n,width:m,height:h,strokeWidth:g,absoluteStrokeWidth:k,nonScalingStroke:b,className:w="",children:_,iconNode:j=[],icon:T={node:j,aliases:[],size:24},...R},$)=>{const{size:C=24,strokeWidth:y=2,absoluteStrokeWidth:E=!1,nonScalingStroke:M=!1,color:N="currentColor",className:S=""}=Dt()??{},X=!!_||jt(R),[I,A,Z=[]]=zt(T,{color:u??N,width:m??n??C,height:h??n??C,strokeWidth:g??y,absoluteStrokeWidth:k??E,nonScalingStroke:b??M,className:le(S,w),hasA11yProp:X,attributes:R});return z.createElement(I,{ref:$,...A},[...Z.map(([q,J])=>z.createElement(q,J)),...Array.isArray(_)?_:[_]])});/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function l(u,n=[],m=[]){const h=typeof u=="string"?Mt(u,n,m):u,g=z.forwardRef(({className:k,...b},w)=>z.createElement(Nt,{ref:w,icon:h,className:k,...b}));return h.name&&(g.displayName=At(h.name)),g}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qe={name:"arrow-right",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]};qe.node;const Lt=l(qe);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const We={name:"arrow-up-right",size:24,node:[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]};We.node;const qt=l(We);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ue={name:"award",size:24,node:[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",key:"1yiouv"}],["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}]]};Ue.node;const Wt=l(Ue);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const He={name:"calendar",size:24,node:[["path",{d:"M8 2v3",key:"1ioesn"}],["path",{d:"M16 2v3",key:"otl347"}],["rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",key:"h1oib"}],["path",{d:"M3 9h18",key:"1pudct"}]]};He.node;const Ut=l(He);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ye={name:"check",size:24,node:[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]};Ye.node;const Ht=l(Ye);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ie={name:"chevron-left",size:24,node:[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]};Ie.node;const Yt=l(Ie);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe={name:"chevron-right",size:24,node:[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]};xe.node;const It=l(xe);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Be={name:"clock",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]]};Be.node;const xt=l(Be);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fe={name:"eye",size:24,node:[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]};Fe.node;const Bt=l(Fe);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ge={name:"flame",size:24,node:[["path",{d:"M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",key:"1slcih"}]]};Ge.node;const Ft=l(Ge);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qe={name:"heart-handshake",size:24,node:[["path",{d:"M19.414 14.414C21 12.828 22 11.5 22 9.5a5.5 5.5 0 0 0-9.591-3.676.6.6 0 0 1-.818.001A5.5 5.5 0 0 0 2 9.5c0 2.3 1.5 4 3 5.5l5.535 5.362a2 2 0 0 0 2.879.052 2.12 2.12 0 0 0-.004-3 2.124 2.124 0 1 0 3-3 2.124 2.124 0 0 0 3.004 0 2 2 0 0 0 0-2.828l-1.881-1.882a2.41 2.41 0 0 0-3.409 0l-1.71 1.71a2 2 0 0 1-2.828 0 2 2 0 0 1 0-2.828l2.823-2.762",key:"17lmqv"}]]};Qe.node;const Gt=l(Qe);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ve={name:"heart",size:24,node:[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",key:"mvr1a0"}]]};Ve.node;const Qt=l(Ve);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ke={name:"map-pin",size:24,node:[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]};Ke.node;const Vt=l(Ke);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xe={name:"menu",size:24,node:[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]]};Xe.node;const Kt=l(Xe);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ze={name:"message-circle",size:24,node:[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]]};Ze.node;const Xt=l(Ze);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Je={name:"message-square",size:24,node:[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]]};Je.node;const Zt=l(Je);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const et={name:"minus",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}]]};et.node;const Jt=l(et);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tt={name:"phone",size:24,node:[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]};tt.node;const en=l(tt);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nt={name:"plus",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]};nt.node;const tn=l(nt);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rt={name:"search",size:24,node:[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]};rt.node;const nn=l(rt);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ot={name:"send",size:24,node:[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]};ot.node;const rn=l(ot);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const at={name:"shield-check",size:24,node:[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]};at.node;const on=l(at);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const st={name:"shopping-bag",size:24,node:[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]]};st.node;const an=l(st);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ut={name:"sliders-horizontal",size:24,node:[["path",{d:"M10 5H3",key:"1qgfaw"}],["path",{d:"M12 19H3",key:"yhmn1j"}],["path",{d:"M14 3v4",key:"1sua03"}],["path",{d:"M16 17v4",key:"1q0r14"}],["path",{d:"M21 12h-9",key:"1o4lsq"}],["path",{d:"M21 19h-5",key:"1rlt1p"}],["path",{d:"M21 5h-7",key:"1oszz2"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M8 12H3",key:"a7s4jb"}]]};ut.node;const sn=l(ut);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const it={name:"sparkles",size:24,node:[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],aliases:["stars"]};it.node;const un=l(it);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ct={name:"trash",size:24,node:[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],aliases:["trash-2"]};ct.node;const cn=l(ct);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lt={name:"truck",size:24,node:[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]]};lt.node;const ln=l(lt);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ft={name:"users-round",size:24,node:[["path",{d:"M18 21a8 8 0 0 0-16 0",key:"3ypg7q"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["path",{d:"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3",key:"10s06x"}]],aliases:["users-2"]};ft.node;const fn=l(ft);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dt={name:"users",size:24,node:[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]};dt.node;const dn=l(dt);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ht={name:"utensils-crossed",size:24,node:[["path",{d:"m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8",key:"n7qcjb"}],["path",{d:"M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7",key:"d0u48b"}],["path",{d:"m2.1 21.8 6.4-6.3",key:"yn04lh"}],["path",{d:"m19 5-7 7",key:"194lzd"}]],aliases:["fork-knife-crossed"]};ht.node;const hn=l(ht);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pt={name:"utensils",size:24,node:[["path",{d:"M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2",key:"cjf0a3"}],["path",{d:"M7 2v20",key:"1473qp"}],["path",{d:"M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7",key:"j28e5"}]],aliases:["fork-knife"]};pt.node;const pn=l(pt);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yt={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};yt.node;const yn=l(yt);export{qt as A,xt as C,Bt as E,Ft as F,Qt as H,Kt as M,en as P,Pt as R,an as S,cn as T,pn as U,yn as X,z as a,Zt as b,Vt as c,Ht as d,tn as e,Jt as f,bt as g,Yt as h,It as i,Xt as j,Ut as k,Lt as l,ln as m,nn as n,sn as o,un as p,dn as q,Rt as r,rn as s,hn as t,fn as u,on as v,Wt as w,Gt as x};
