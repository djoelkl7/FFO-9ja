function mt(u){return u&&u.__esModule&&Object.prototype.hasOwnProperty.call(u,"default")?u.default:u}var ie={exports:{}},H={exports:{}};H.exports;var De;function _t(){return De||(De=1,(function(u,n){/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(){function m(e,t){Object.defineProperty(_.prototype,e,{get:function(){console.warn("%s(...) is deprecated in plain JavaScript React classes. %s",t[0],t[1])}})}function d(e){return e===null||typeof e!="object"?null:(e=Ee&&e[Ee]||e["@@iterator"],typeof e=="function"?e:null)}function k(e,t){e=(e=e.constructor)&&(e.displayName||e.name)||"ReactClass";var r=e+"."+t;be[r]||(console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",t,e),be[r]=!0)}function _(e,t,r){this.props=e,this.context=t,this.refs=se,this.updater=r||Te}function b(){}function w(e,t,r){this.props=e,this.context=t,this.refs=se,this.updater=r||Te}function v(){}function z(e){return""+e}function T(e){try{z(e);var t=!1}catch{t=!0}if(t){t=console;var r=t.error,o=typeof Symbol=="function"&&Symbol.toStringTag&&e[Symbol.toStringTag]||e.constructor.name||"Object";return r.call(t,"The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",o),z(e)}}function R(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===ft?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case re:return"Fragment";case me:return"Profiler";case ye:return"StrictMode";case ge:return"Suspense";case lt:return"SuspenseList";case ke:return"Activity";case we:return"ViewTransition"}if(typeof e=="object")switch(typeof e.tag=="number"&&console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."),e.$$typeof){case pe:return"Portal";case _e:return e.displayName||"Context";case oe:return(e._context.displayName||"Context")+".Consumer";case ve:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case ae:return t=e.displayName||null,t!==null?t:R(e.type)||"Memo";case U:t=e._payload,e=e._init;try{return R(e(t))}catch{}}return null}function $(e){if(e===re)return"<>";if(typeof e=="object"&&e!==null&&e.$$typeof===U)return"<...>";try{var t=R(e);return t?"<"+t+">":"<...>"}catch{return"<...>"}}function C(){var e=c.A;return e===null?null:e.getOwner()}function y(){return Error("react-stack-top-frame")}function E(e){if(G.call(e,"key")){var t=Object.getOwnPropertyDescriptor(e,"key").get;if(t&&t.isReactWarning)return!1}return e.key!==void 0}function S(e,t){function r(){Ae||(Ae=!0,console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",t))}r.isReactWarning=!0,Object.defineProperty(e,"key",{get:r,configurable:!0})}function P(){var e=R(this.type);return Me[e]||(Me[e]=!0,console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release.")),e=this.props.ref,e!==void 0?e:null}function A(e,t,r,o,a,f){var s=r.ref;return e={$$typeof:ne,type:e,key:t,props:r,_owner:o},(s!==void 0?s:null)!==null?Object.defineProperty(e,"ref",{enumerable:!1,get:P}):Object.defineProperty(e,"ref",{enumerable:!1,value:null}),e._store={},Object.defineProperty(e._store,"validated",{configurable:!1,enumerable:!1,writable:!0,value:0}),Object.defineProperty(e,"_debugInfo",{configurable:!1,enumerable:!1,writable:!0,value:null}),Object.defineProperty(e,"_debugStack",{configurable:!1,enumerable:!1,writable:!0,value:a}),Object.defineProperty(e,"_debugTask",{configurable:!1,enumerable:!1,writable:!0,value:f}),Object.freeze&&(Object.freeze(e.props),Object.freeze(e)),e}function X(e,t){return t=A(e.type,t,e.props,e._owner,e._debugStack,e._debugTask),e._store&&(t._store.validated=e._store.validated),t}function I(e){O(e)?e._store&&(e._store.validated=1):typeof e=="object"&&e!==null&&e.$$typeof===U&&(e._payload.status==="fulfilled"?O(e._payload.value)&&e._payload.value._store&&(e._payload.value._store.validated=1):e._store&&(e._store.validated=1))}function O(e){return typeof e=="object"&&e!==null&&e.$$typeof===ne}function Z(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(r){return t[r]})}function q(e,t){return typeof e=="object"&&e!==null&&e.key!=null?(T(e.key),Z(""+e.key)):t.toString(36)}function J(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(v,v):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function D(e,t,r,o,a){var f=typeof e;(f==="undefined"||f==="boolean")&&(e=null);var s=!1;if(e===null)s=!0;else switch(f){case"bigint":case"string":case"number":s=!0;break;case"object":switch(e.$$typeof){case ne:case pe:s=!0;break;case U:return s=e._init,D(s(e._payload),t,r,o,a)}}if(s){s=e,a=a(s);var i=o===""?"."+q(s,0):o;return Ce(a)?(r="",i!=null&&(r=i.replace(ze,"$&/")+"/"),D(a,t,r,"",function(M){return M})):a!=null&&(O(a)&&(a.key!=null&&(s&&s.key===a.key||T(a.key)),r=X(a,r+(a.key==null||s&&s.key===a.key?"":(""+a.key).replace(ze,"$&/")+"/")+i),o!==""&&s!=null&&O(s)&&s.key==null&&s._store&&!s._store.validated&&(r._store.validated=2),a=r),t.push(a)),1}if(s=0,i=o===""?".":o+":",Ce(e))for(var l=0;l<e.length;l++)o=e[l],f=i+q(o,l),s+=D(o,t,r,f,a);else if(l=d(e),typeof l=="function")for(l===e.entries&&(je||console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."),je=!0),e=l.call(e),l=0;!(o=e.next()).done;)o=o.value,f=i+q(o,l++),s+=D(o,t,r,f,a);else if(f==="object"){if(typeof e.then=="function")return D(J(e),t,r,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return s}function B(e,t,r){if(e==null)return e;var o=[],a=0;return D(e,o,"","",function(f){return t.call(r,f,a++)}),o}function ct(e){if(e._status===-1){var t=null,r=null,o=e._ioInfo;o!=null&&(o.start=o.end=performance.now(),o.value=new Promise(function(s,i){t=s,r=i})),o=e._result;var a=o();if(a.then(function(s){if(e._status===0||e._status===-1){e._status=1,e._result=s;var i=e._ioInfo;if(i!=null){i.end=performance.now();var l=s==null?void 0:s.default;t(l),i.value.status="fulfilled",i.value.value=l}a.status===void 0&&(a.status="fulfilled",a.value=s)}},function(s){if(e._status===0||e._status===-1){e._status=2,e._result=s;var i=e._ioInfo;i!=null&&(i.end=performance.now(),i.value.then(v,v),r(s),i.value.status="rejected",i.value.reason=s),a.status===void 0&&(a.status="rejected",a.reason=s)}}),o=e._ioInfo,o!=null){var f=a.displayName;typeof f=="string"&&(o.name=f)}e._status===-1&&(e._status=0,e._result=a)}if(e._status===1)return o=e._result,o===void 0&&console.error(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`,o),"default"in o||console.error(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`,o),o.default;throw e._result}function p(){var e=c.H;return e===null&&console.error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`),e}function fe(){c.asyncTransitions--}function de(e){var t=c.T,r={};r.types=t!==null?t.types:null,r._updatedFibers=new Set,c.T=r;try{var o=e(),a=c.S;a!==null&&a(r,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&(c.asyncTransitions++,o.then(fe,fe),o.then(v,$e))}catch(f){$e(f)}finally{t===null&&r._updatedFibers&&(e=r._updatedFibers.size,r._updatedFibers.clear(),10<e&&console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")),t!==null&&r.types!==null&&(t.types!==null&&t.types!==r.types&&console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."),t.types=r.types),c.T=t}}function he(e){var t=c.T;if(t!==null){var r=t.types;r===null?t.types=[e]:r.indexOf(e)===-1&&r.push(e)}else c.asyncTransitions===0&&console.error("addTransitionType can only be called inside a `startTransition()` callback. It must be associated with a specific Transition."),de(he.bind(null,e))}function x(e){if(Q===null)try{var t=("require"+Math.random()).slice(0,7);Q=(u&&u[t]).call(u,"timers").setImmediate}catch{Q=function(o){Ne===!1&&(Ne=!0,typeof MessageChannel>"u"&&console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));var a=new MessageChannel;a.port1.onmessage=o,a.port2.postMessage(void 0)}}return Q(e)}function W(e){return 1<e.length&&typeof AggregateError=="function"?new AggregateError(e):e[0]}function F(e,t){t!==K-1&&console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "),K=t}function ee(e,t,r){var o=c.actQueue;if(o!==null)if(o.length!==0)try{te(o),x(function(){return ee(e,t,r)});return}catch(a){c.thrownErrors.push(a)}else c.actQueue=null;0<c.thrownErrors.length?(o=W(c.thrownErrors),c.thrownErrors.length=0,r(o)):t(e)}function te(e){if(!ue){ue=!0;var t=0;try{for(;t<e.length;t++){var r=e[t];do{c.didUsePromise=!1;var o=r(!1);if(o!==null){if(c.didUsePromise){e[t]=r,e.splice(0,t);return}r=o}else break}while(!0)}e.length=0}catch(a){e.splice(0,t+1),c.thrownErrors.push(a)}finally{ue=!1}}}typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart=="function"&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());var ne=Symbol.for("react.transitional.element"),pe=Symbol.for("react.portal"),re=Symbol.for("react.fragment"),ye=Symbol.for("react.strict_mode"),me=Symbol.for("react.profiler"),oe=Symbol.for("react.consumer"),_e=Symbol.for("react.context"),ve=Symbol.for("react.forward_ref"),ge=Symbol.for("react.suspense"),lt=Symbol.for("react.suspense_list"),ae=Symbol.for("react.memo"),U=Symbol.for("react.lazy"),ke=Symbol.for("react.activity"),we=Symbol.for("react.view_transition"),Ee=Symbol.iterator,be={},Te={isMounted:function(){return!1},enqueueForceUpdate:function(e){k(e,"forceUpdate")},enqueueReplaceState:function(e){k(e,"replaceState")},enqueueSetState:function(e){k(e,"setState")}},Re=Object.assign,se={};Object.freeze(se),_.prototype.isReactComponent={},_.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},_.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};var g={isMounted:["isMounted","Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],replaceState:["replaceState","Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]};for(Y in g)g.hasOwnProperty(Y)&&m(Y,g[Y]);b.prototype=_.prototype,g=w.prototype=new b,g.constructor=w,Re(g,_.prototype),g.isPureReactComponent=!0;var Ce=Array.isArray,ft=Symbol.for("react.client.reference"),c={H:null,A:null,T:null,S:null,actQueue:null,asyncTransitions:0,isBatchingLegacy:!1,didScheduleLegacyUpdate:!1,didUsePromise:!1,thrownErrors:[],getCurrentStack:null,recentlyCreatedOwnerStacks:0},G=Object.prototype.hasOwnProperty,Se=console.createTask?console.createTask:function(){return null};g={react_stack_bottom_frame:function(e){return e()}};var Ae,Oe,Me={},dt=g.react_stack_bottom_frame.bind(g,y)(),ht=Se($(y)),je=!1,ze=/\/+/g,$e=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Ne=!1,Q=null,K=0,V=!1,ue=!1,Pe=typeof queueMicrotask=="function"?function(e){queueMicrotask(function(){return queueMicrotask(e)})}:x;g=Object.freeze({__proto__:null,c:function(e){return p().useMemoCache(e)}});var Y={map:B,forEach:function(e,t,r){B(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return B(e,function(){t++}),t},toArray:function(e){return B(e,function(t){return t})||[]},only:function(e){if(!O(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};n.Activity=ke,n.Children=Y,n.Component=_,n.Fragment=re,n.Profiler=me,n.PureComponent=w,n.StrictMode=ye,n.Suspense=ge,n.ViewTransition=we,n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=c,n.__COMPILER_RUNTIME=g,n.act=function(e){var t=c.actQueue,r=K;K++;var o=c.actQueue=t!==null?t:[],a=!1;try{var f=e()}catch(l){c.thrownErrors.push(l)}if(0<c.thrownErrors.length)throw F(t,r),e=W(c.thrownErrors),c.thrownErrors.length=0,e;if(f!==null&&typeof f=="object"&&typeof f.then=="function"){var s=f;return Pe(function(){a||V||(V=!0,console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"))}),{then:function(l,M){a=!0,s.then(function(L){if(F(t,r),r===0){try{te(o),x(function(){return ee(L,l,M)})}catch(yt){c.thrownErrors.push(yt)}if(0<c.thrownErrors.length){var pt=W(c.thrownErrors);c.thrownErrors.length=0,M(pt)}}else l(L)},function(L){F(t,r),0<c.thrownErrors.length&&(L=W(c.thrownErrors),c.thrownErrors.length=0),M(L)})}}}var i=f;if(F(t,r),r===0&&(te(o),o.length!==0&&Pe(function(){a||V||(V=!0,console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"))}),c.actQueue=null),0<c.thrownErrors.length)throw e=W(c.thrownErrors),c.thrownErrors.length=0,e;return{then:function(l,M){a=!0,r===0?(c.actQueue=o,x(function(){return ee(i,l,M)})):l(i)}}},n.addTransitionType=he,n.cache=function(e){return function(){return e.apply(null,arguments)}},n.cacheSignal=function(){return null},n.captureOwnerStack=function(){var e=c.getCurrentStack;return e===null?null:e()},n.cloneElement=function(e,t,r){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=Re({},e.props),a=e.key,f=e._owner;if(t!=null){var s;e:{if(G.call(t,"ref")&&(s=Object.getOwnPropertyDescriptor(t,"ref").get)&&s.isReactWarning){s=!1;break e}s=t.ref!==void 0}s&&(f=C()),E(t)&&(T(t.key),a=""+t.key);for(i in t)!G.call(t,i)||i==="key"||i==="__self"||i==="__source"||i==="ref"&&t.ref===void 0||(o[i]=t[i])}var i=arguments.length-2;if(i===1)o.children=r;else if(1<i){s=Array(i);for(var l=0;l<i;l++)s[l]=arguments[l+2];o.children=s}for(o=A(e.type,a,o,f,e._debugStack,e._debugTask),a=2;a<arguments.length;a++)I(arguments[a]);return o},n.createContext=function(e){return e={$$typeof:_e,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:oe,_context:e},e._currentRenderer=null,e._currentRenderer2=null,e},n.createElement=function(e,t,r){for(var o=2;o<arguments.length;o++)I(arguments[o]);var a;o={};var f=null;if(t!=null)for(a in Oe||!("__self"in t)||"key"in t||(Oe=!0,console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")),E(t)&&(T(t.key),f=""+t.key),t)G.call(t,a)&&a!=="key"&&a!=="__self"&&a!=="__source"&&(o[a]=t[a]);var s=arguments.length-2;if(s===1)o.children=r;else if(1<s){for(var i=Array(s),l=0;l<s;l++)i[l]=arguments[l+2];Object.freeze&&Object.freeze(i),o.children=i}if(e&&e.defaultProps)for(a in s=e.defaultProps,s)o[a]===void 0&&(o[a]=s[a]);return f&&S(o,typeof e=="function"?e.displayName||e.name||"Unknown":e),(a=1e4>c.recentlyCreatedOwnerStacks++)?(i=Error.stackTraceLimit,Error.stackTraceLimit=10,s=Error("react-stack-top-frame"),Error.stackTraceLimit=i):s=dt,A(e,f,o,C(),s,a?Se($(e)):ht)},n.createRef=function(){var e={current:null};return Object.seal(e),e},n.forwardRef=function(e){e!=null&&e.$$typeof===ae?console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."):typeof e!="function"?console.error("forwardRef requires a render function but was given %s.",e===null?"null":typeof e):e.length!==0&&e.length!==2&&console.error("forwardRef render functions accept exactly two parameters: props and ref. %s",e.length===1?"Did you forget to use the ref parameter?":"Any additional parameter will be undefined."),e!=null&&e.defaultProps!=null&&console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");var t={$$typeof:ve,render:e},r;return Object.defineProperty(t,"displayName",{enumerable:!1,configurable:!0,get:function(){return r},set:function(o){r=o,e.name||e.displayName||(Object.defineProperty(e,"name",{value:o}),e.displayName=o)}}),t},n.isValidElement=O,n.lazy=function(e){e={_status:-1,_result:e};var t={$$typeof:U,_payload:e,_init:ct},r={name:"lazy",start:-1,end:-1,value:null,owner:null,debugStack:Error("react-stack-top-frame"),debugTask:console.createTask?console.createTask("lazy()"):null};return e._ioInfo=r,t._debugInfo=[{awaited:r}],t},n.memo=function(e,t){e==null&&console.error("memo: The first argument must be a component. Instead received: %s",e===null?"null":typeof e),t={$$typeof:ae,type:e,compare:t===void 0?null:t};var r;return Object.defineProperty(t,"displayName",{enumerable:!1,configurable:!0,get:function(){return r},set:function(o){r=o,e.name||e.displayName||(Object.defineProperty(e,"name",{value:o}),e.displayName=o)}}),t},n.startTransition=de,n.unstable_useCacheRefresh=function(){return p().useCacheRefresh()},n.use=function(e){return p().use(e)},n.useActionState=function(e,t,r){return p().useActionState(e,t,r)},n.useCallback=function(e,t){return p().useCallback(e,t)},n.useContext=function(e){var t=p();return e.$$typeof===oe&&console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?"),t.useContext(e)},n.useDebugValue=function(e,t){return p().useDebugValue(e,t)},n.useDeferredValue=function(e,t){return p().useDeferredValue(e,t)},n.useEffect=function(e,t){return e==null&&console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?"),p().useEffect(e,t)},n.useEffectEvent=function(e){return p().useEffectEvent(e)},n.useId=function(){return p().useId()},n.useImperativeHandle=function(e,t,r){return p().useImperativeHandle(e,t,r)},n.useInsertionEffect=function(e,t){return e==null&&console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?"),p().useInsertionEffect(e,t)},n.useLayoutEffect=function(e,t){return e==null&&console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?"),p().useLayoutEffect(e,t)},n.useMemo=function(e,t){return p().useMemo(e,t)},n.useOptimistic=function(e,t){return p().useOptimistic(e,t)},n.useReducer=function(e,t,r){return p().useReducer(e,t,r)},n.useRef=function(e){return p().useRef(e)},n.useState=function(e){return p().useState(e)},n.useSyncExternalStore=function(e,t,r){return p().useSyncExternalStore(e,t,r)},n.useTransition=function(){return p().useTransition()},n.version="19.3.1",typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop=="function"&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error())})()})(H,H.exports)),H.exports}var Le;function vt(){return Le||(Le=1,ie.exports=_t()),ie.exports}var j=vt();const Ot=mt(j);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gt=u=>u==null?void 0:u.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function kt(u,n,m=[]){if(n==null)throw new Error("[lucide]: iconNode is required when icon name is used");return{name:gt(u),size:24,node:n,...m.length>0?{aliases:m}:{}}}/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wt=u=>{let n="",m=!1;for(const d of u){if(d==="-"||d==="_"||d<=" "){m=n.length>0;continue}n.length===0?n+=d.toLowerCase():n+=m?d.toUpperCase():d,m=!1}return n};/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Et=u=>{const n=wt(u);return n.charAt(0).toUpperCase()+n.slice(1)};/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=(...u)=>u.filter((n,m,d)=>!!n&&n.trim()!==""&&d.indexOf(n)===m).join(" ").trim();/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function ce(u){return u!=null}function bt(u,n={}){var $,C;const m=n.attributeNames??{},d=y=>m[y]??y,k=u.size??u.width??N.width,_=u.size??u.height??N.height,b=(($=u.aliases)==null?void 0:$.filter(y=>typeof y=="string"&&y.trim()!=="").map(y=>`lucide-${y}`))??[],w=[...u.name?[`lucide-${u.name}`]:[],...b],v=((C=n.className)==null?void 0:C.split(" ").filter(Boolean))??[],z=n.includeDefaultClasses===!1?le(...v):le("lucide",...w,...v),T=n.absoluteStrokeWidth?Number(n.strokeWidth??N["stroke-width"])*Number(u.size??u.width??N.width)/Number(n.size??n.width??N.width):n.strokeWidth??N["stroke-width"];return["svg",{...Object.entries(N).reduce((y,[E,S])=>(y[d(E)]=S,y),{}),..."color"in n&&n.color&&{[d("stroke")]:n.color},..."size"in n&&ce(n.size)&&{[d("width")]:n.size,[d("height")]:n.size},..."width"in n&&ce(n.width)&&{[d("width")]:n.width},..."height"in n&&ce(n.height)&&{[d("height")]:n.height},[d("stroke-width")]:T,...z&&{[d("class")]:z},[d("viewBox")]:`0 0 ${k} ${_}`,...n.hasA11yProp===!1?{[d("aria-hidden")]:"true"}:{},..."attributes"in n&&n.attributes},u.node.map(y=>{const[E,S,P]=y,A=n.nonScalingStroke?{[d("vector-effect")]:"non-scaling-stroke",...S}:S;return P?[E,A,P]:[E,A]})]}/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function Tt(u,n={}){return bt(u,{...n,attributeNames:{...n.attributeNames,class:"className","stroke-width":"strokeWidth","stroke-linecap":"strokeLinecap","stroke-linejoin":"strokeLinejoin","vector-effect":"vectorEffect"}})}/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rt=u=>{for(const n in u)if(n.startsWith("aria-")||n==="role"||n==="title")return!0;return!1},Ct=j.createContext({}),St=()=>j.useContext(Ct),At=j.forwardRef(({color:u,size:n,width:m,height:d,strokeWidth:k,absoluteStrokeWidth:_,nonScalingStroke:b,className:w="",children:v,iconNode:z=[],icon:T={node:z,aliases:[],size:24},...R},$)=>{const{size:C=24,strokeWidth:y=2,absoluteStrokeWidth:E=!1,nonScalingStroke:S=!1,color:P="currentColor",className:A=""}=St()??{},X=!!v||Rt(R),[I,O,Z=[]]=Tt(T,{color:u??P,width:m??n??C,height:d??n??C,strokeWidth:k??y,absoluteStrokeWidth:_??E,nonScalingStroke:b??S,className:le(A,w),hasA11yProp:X,attributes:R});return j.createElement(I,{ref:$,...O},[...Z.map(([q,J])=>j.createElement(q,J)),...Array.isArray(v)?v:[v]])});/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function h(u,n=[],m=[]){const d=typeof u=="string"?kt(u,n,m):u,k=j.forwardRef(({className:_,...b},w)=>j.createElement(At,{ref:w,icon:d,className:_,...b}));return d.name&&(k.displayName=Et(d.name)),k}/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qe={name:"arrow-right",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]};qe.node;const Mt=h(qe);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const We={name:"arrow-up-right",size:24,node:[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]};We.node;const jt=h(We);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ue={name:"check",size:24,node:[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]};Ue.node;const zt=h(Ue);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ye={name:"chevron-left",size:24,node:[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]};Ye.node;const $t=h(Ye);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const He={name:"chevron-right",size:24,node:[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]};He.node;const Nt=h(He);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ie={name:"clock",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]]};Ie.node;const Pt=h(Ie);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Be={name:"eye",size:24,node:[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]};Be.node;const Dt=h(Be);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe={name:"flame",size:24,node:[["path",{d:"M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",key:"1slcih"}]]};xe.node;const Lt=h(xe);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fe={name:"heart",size:24,node:[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",key:"mvr1a0"}]]};Fe.node;const qt=h(Fe);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ge={name:"map-pin",size:24,node:[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]};Ge.node;const Wt=h(Ge);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qe={name:"menu",size:24,node:[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]]};Qe.node;const Ut=h(Qe);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ke={name:"message-square",size:24,node:[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]]};Ke.node;const Yt=h(Ke);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ve={name:"minus",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}]]};Ve.node;const Ht=h(Ve);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xe={name:"phone",size:24,node:[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]};Xe.node;const It=h(Xe);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ze={name:"plus",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]};Ze.node;const Bt=h(Ze);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Je={name:"search",size:24,node:[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]};Je.node;const xt=h(Je);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const et={name:"send",size:24,node:[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]};et.node;const Ft=h(et);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tt={name:"shopping-bag",size:24,node:[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]]};tt.node;const Gt=h(tt);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nt={name:"sliders-horizontal",size:24,node:[["path",{d:"M10 5H3",key:"1qgfaw"}],["path",{d:"M12 19H3",key:"yhmn1j"}],["path",{d:"M14 3v4",key:"1sua03"}],["path",{d:"M16 17v4",key:"1q0r14"}],["path",{d:"M21 12h-9",key:"1o4lsq"}],["path",{d:"M21 19h-5",key:"1rlt1p"}],["path",{d:"M21 5h-7",key:"1oszz2"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M8 12H3",key:"a7s4jb"}]]};nt.node;const Qt=h(nt);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rt={name:"trash",size:24,node:[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],aliases:["trash-2"]};rt.node;const Kt=h(rt);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ot={name:"users-round",size:24,node:[["path",{d:"M18 21a8 8 0 0 0-16 0",key:"3ypg7q"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["path",{d:"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3",key:"10s06x"}]],aliases:["users-2"]};ot.node;const Vt=h(ot);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const at={name:"users",size:24,node:[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]};at.node;const Xt=h(at);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const st={name:"utensils-crossed",size:24,node:[["path",{d:"m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8",key:"n7qcjb"}],["path",{d:"M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7",key:"d0u48b"}],["path",{d:"m2.1 21.8 6.4-6.3",key:"yn04lh"}],["path",{d:"m19 5-7 7",key:"194lzd"}]],aliases:["fork-knife-crossed"]};st.node;const Zt=h(st);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ut={name:"utensils",size:24,node:[["path",{d:"M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2",key:"cjf0a3"}],["path",{d:"M7 2v20",key:"1473qp"}],["path",{d:"M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7",key:"j28e5"}]],aliases:["fork-knife"]};ut.node;const Jt=h(ut);/**
 * @license lucide-react v1.67.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const it={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};it.node;const en=h(it);export{jt as A,Pt as C,Dt as E,Lt as F,qt as H,Ut as M,It as P,Ot as R,Gt as S,Kt as T,Xt as U,en as X,j as a,Yt as b,Wt as c,zt as d,Bt as e,Ht as f,mt as g,$t as h,Nt as i,Mt as j,xt as k,Qt as l,Jt as m,Ft as n,Zt as o,Vt as p,vt as r};
