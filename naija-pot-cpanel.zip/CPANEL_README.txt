================================================================================
NAIJA POT KITCHEN & GRILL LTD — cPanel Deployment Package
================================================================================

HOW TO DEPLOY TO CPANEL IN 3 SIMPLE STEPS:

1. Log into your cPanel dashboard (e.g. https://yourdomain.com:2083).
2. Open "File Manager" and navigate to "public_html" (or your subdomain folder).
   - If there are existing default files, back them up or clear out previous old files.
3. Upload "naija-pot-cpanel.zip" into public_html, right-click the zip, and click "Extract".
4. Navigate to your hosting URL (e.g. https://yourdomain.com) to view your live website!

That's it! Your website is live with:
- Full SPA client-side navigation (hash routing works out-of-the-box on all hosts)
- Apache .htaccess URL rewriting (no 404s on direct page refresh)
- Gzip/Deflate compression for fast mobile loading
- 1-year browser caching for CSS, JS, and images
- Robots.txt & Sitemap.xml pre-configured
- WhatsApp ordering and custom meal inquiries

Need SSL? In cPanel, click "SSL/TLS Status" -> "Run AutoSSL".
To enforce HTTPS, open the .htaccess file in File Manager and uncomment the HTTPS rewrite lines.
================================================================================
