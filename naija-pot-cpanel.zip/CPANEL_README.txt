================================================================================
NAIJA POT KITCHEN & GRILL LTD — cPanel / Hostinger Production Package
File: FFO-9ja-cPanel-Production-Ready.zip
================================================================================

HOW TO DEPLOY TO CPANEL OR HOSTINGER IN 3 SIMPLE STEPS:

1. Log into your hosting control panel (Hostinger hPanel or cPanel File Manager).
2. Open "File Manager" and navigate to "public_html" (or your website root directory).
   - If there are old or default placeholder files, back them up or remove them.
3. Upload "FFO-9ja-cPanel-Production-Ready.zip" into public_html.
4. Right-click the zip file and select "Extract" (extract directly into public_html).
   - This places index.html directly inside public_html (no nested dist/ folder!).
5. Navigate to your website URL (e.g. https://yourdomain.com) to view your live website!

WHAT THIS PACKAGE INCLUDES:
- Complete production HTML, CSS, JavaScript, and fonts
- Pre-configured Apache .htaccess with SPA client-side rewrite rules (no 404s on refresh)
- High-performance Gzip/Deflate compression and browser caching rules
- SEO sitemap.xml and robots.txt
- Full Nigerian menu, bakery selection, catering inquiries, and WhatsApp ordering
- Fully responsive for mobile, tablet, and desktop

Need SSL/HTTPS?
- In cPanel, click "SSL/TLS Status" -> "Run AutoSSL" (or SSL in Hostinger hPanel).
- Once SSL is active, you can uncomment the HTTPS rewrite lines in .htaccess.
================================================================================
