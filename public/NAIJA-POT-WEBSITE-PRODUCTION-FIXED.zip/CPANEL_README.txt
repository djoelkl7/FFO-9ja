================================================================================
NAIJA POT KITCHEN & GRILL LTD — Production Hosting Package
File: NAIJA-POT-WEBSITE-PRODUCTION-FIXED.zip
Official Website: https://naijapotkitchengrill.co.uk/
================================================================================

HOW TO DEPLOY TO CPANEL OR HOSTINGER IN 4 SIMPLE STEPS:

1. Log into your hosting control panel (Hostinger hPanel or cPanel File Manager).
2. Open "File Manager" and navigate to "public_html" (or your domain root folder).
   - Back up any old website files before removing them.
3. Upload "NAIJA-POT-WEBSITE-PRODUCTION-FIXED.zip" directly into public_html.
4. Right-click "NAIJA-POT-WEBSITE-PRODUCTION-FIXED.zip" and select "Extract" into public_html.
   - Ensure index.html is placed directly inside public_html/ (not inside a subfolder).
5. Visit https://naijapotkitchengrill.co.uk/ to verify your live website!

WHAT THIS PACKAGE INCLUDES:
- Complete production HTML, CSS, JavaScript, fonts, and food photography
- Pre-configured canonical, OpenGraph, Twitter, and JSON-LD SEO metadata
- Clean sitemap.xml and robots.txt pointing to https://naijapotkitchengrill.co.uk/
- Pre-rendered route folders (/event-caterers/, /menu/, /bakery/, /specials/, /story/, /contact/)
- Pre-configured Apache .htaccess with SPA fallback routing, Gzip compression, and caching
- Zero placeholder domain references

Need SSL/HTTPS?
- In cPanel: SSL/TLS Status -> Run AutoSSL (or SSL in Hostinger hPanel).
- Once SSL is active, uncomment the HTTPS rewrite lines in .htaccess.
================================================================================
